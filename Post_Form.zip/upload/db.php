<?php
  $host="localhost";
  $password="";
  $username="root";
  $db="upload";
  $con=mysqli_connect($host,$username,$password,$db);
  

?>