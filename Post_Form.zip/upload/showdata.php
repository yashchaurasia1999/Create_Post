
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css?family=Roboto:400,700" rel="stylesheet">
<title>create</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
<style>
  .container{
    display:flex;
    justify-content:center;
  }
  .btn{
    display:flex;
    justify-content:center;
  }
  .center{
    display:flex;
    justify-content:center;
  }
</style>
<body>



  <h2 class='text-center'>Show Posts</h2>
  <div class='container'>
  <table class="table table-striped">
  <thead>
    <tr>
      
      <th scope="col">Title</th>
      <th scope="col">Create Date</th>
      <th scope="col">Author</th>
      <th scope="col">Delete</th>

    </tr>
  </thead>
  <tbody>
  <?php
  include "db.php";
  $query="select * from photo";
  $res=mysqli_query($con,$query);
  $fetch=mysqli_fetch_array($res);
  while($fetch=mysqli_fetch_array($res))
  {
      ?><tr>
      
      <td><?php echo $fetch['Title']?></td>
      <td><?php echo $fetch['Create_Date']?></td>
      <td><?php echo $fetch['Author']?></td>
      <td><input type ='button' value='Delete'></td>
    </tr>
      <?php


  }
?>
    
  </tbody>
</table>

  </div>
<div class='center'>
<nav aria-label="...">
  <ul class="pagination">
    <li class="page-item disabled">
      <span class="page-link">Previous</span>
    </li>
    <li class="page-item active"><a class="page-link" href="#">1</a></li>
    <li class="page-item" aria-current="page">
      <span class="page-link">2</span>
    </li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item">
      <a class="page-link" href="#">Next</a>
    </li>
  </ul>
</nav>
</div>
  
  <br><br>
  <div class='btn'>
    <button type="button" class="btn btn-primary" ><a style='color:white' href="user_input.php">Add More Data</a></button>
  </div>
  
</body>
</html>